//
//  DragModalDialogAppDelegate.h
//  DragModalDialog
//
//  Created by David E. Wheeler on 1/29/11.
//  Copyright 2011 Kineticode, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DragModalDialogViewController;

@interface DragModalDialogAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DragModalDialogViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DragModalDialogViewController *viewController;

@end

