//
//  DragModalDialogViewController.h
//  DragModalDialog
//
//  Created by David E. Wheeler on 1/29/11.
//  Copyright 2011 Kineticode, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DragModalDialogViewController : UIViewController {
    CGFloat modalViewYStart;
}

- (IBAction)openModalViewController;

@end
