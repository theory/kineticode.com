//
//  MyModalViewController.h
//  DragModalDialog
//
//  Created by David E. Wheeler on 1/29/11.
//  Copyright 2011 Kineticode, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyModalViewController : UIViewController {
    UIToolbar *toolbar;
}

@property (nonatomic, retain) IBOutlet UIToolbar *toolbar;

- (IBAction)closeModalViewController;
- (IBAction)changeBackgoundColor;

@end
