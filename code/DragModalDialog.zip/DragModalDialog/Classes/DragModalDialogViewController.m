//
//  DragModalDialogViewController.m
//  DragModalDialog
//
//  Created by David E. Wheeler on 1/29/11.
//  Copyright 2011 Kineticode, Inc. All rights reserved.
//

#import "DragModalDialogViewController.h"
#import "MyModalViewController.h"

@interface DragModalDialogViewController ()
- (void)handlePan:(UIPanGestureRecognizer *)gestureRecognizer;
@end


@implementation DragModalDialogViewController


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


- (void)viewDidLoad {
    self.view.backgroundColor = [UIColor colorWithPatternImage: [UIImage imageNamed:@"main_bg_tile.png"]];
    [super viewDidLoad];
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void)openModalViewController {
    MyModalViewController *mmvc = [[MyModalViewController alloc]init];
    mmvc.modalPresentationStyle = UIModalPresentationPageSheet;
    [self presentModalViewController:mmvc animated:YES];

    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
    pan.maximumNumberOfTouches = 2;
    [mmvc.toolbar addGestureRecognizer:pan];
    [pan release];
    [mmvc release];    
}

- (void)handlePan:(UIPanGestureRecognizer *)gestureRecognizer {
    UIView *piece = [gestureRecognizer view];
    UIView *modalView = self.modalViewController.view;
    
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        modalViewYStart = modalView.center.y;
    }
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan || [gestureRecognizer state] == UIGestureRecognizerStateChanged) {
        CGPoint translation = [gestureRecognizer translationInView:[piece superview]];
        if ([modalView center].y + translation.y > modalViewYStart) {
            [modalView setCenter:CGPointMake([modalView center].x, [modalView center].y + translation.y)];
        }
        [gestureRecognizer setTranslation:CGPointZero inView:[piece superview]];
    }
    if (gestureRecognizer.state == UIGestureRecognizerStateEnded) {
        if ((modalView.center.y - modalViewYStart) > 100) {
            [self dismissModalViewControllerAnimated:YES];
        } else {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDelegate:self];
            CGRect frame = modalView.frame;
            frame.origin.y = 0;
            modalView.frame = frame;
            [UIView commitAnimations];
        }
    }
}

- (void)dealloc {
    [super dealloc];
}

@end
