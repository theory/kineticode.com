package Bric::Biz::Asset::Formatting;
###############################################################################

=head1 NAME

Bric::Biz::Asset::Formatting - Deprecated; use Bric::Biz::Asset::Template instead

=head1 VERSION

$LastChangedRevision$

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 DATE

$LastChangedDate: 2005-09-23 16:42:51 -0700 (Fri, 23 Sep 2005) $

=head1 DESCRIPTION

The functionality of this class has been moved to
L<Bric::Biz::Asset::Template|Bric::Biz::Asset::Tempmlate>. Please use that
class, instead.

=cut

use base 'Bric::Biz::Asset::Template';

1;
__END__
