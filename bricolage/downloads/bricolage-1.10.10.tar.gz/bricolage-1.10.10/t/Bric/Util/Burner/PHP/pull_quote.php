<blockquote>
<p><?= $element->get_value('para') ?></p>
<p>--<?= $element->get_value('by') ?>, <?= $element->get_value('date', 1, '%Y.%m.%d') ?></p>
</blockquote>
