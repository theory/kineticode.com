package Bric::Biz::Asset::Business::Parts::Tile::Data;

###############################################################################

=head1 Name

Bric::Biz::Asset::Business::Parts::Tile::Data - Deprecated; use Bric::Biz::Element::Field instead

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 Description

The functionality of this class has been moved to
L<Bric::Biz::Element::Field|Bric::Biz::Element::Field>. Please use that class,
instead.

=cut

use base 'Bric::Biz::Element::Field';

1;
__END__
