package Bric::Biz::Asset::Formatting;

###############################################################################

=head1 Name

Bric::Biz::Asset::Formatting - Deprecated; use Bric::Biz::Asset::Template instead

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 Description

The functionality of this class has been moved to
L<Bric::Biz::Asset::Template|Bric::Biz::Asset::Tempmlate>. Please use that
class, instead.

=cut

use base 'Bric::Biz::Asset::Template';

1;
__END__
