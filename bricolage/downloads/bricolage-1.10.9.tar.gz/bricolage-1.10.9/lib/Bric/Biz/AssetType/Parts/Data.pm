package Bric::Biz::AssetType::Parts::Data;
###############################################################################

=head1 NAME

Bric::Biz::AssetType::Parts::Data - Deprecated; use Bric::Biz::ElementType::Parts::FieldType instead

=head1 VERSION

$LastChangedRevision$

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 DATE

$LastChangedDate$

=head1 DESCRIPTION

The functionality of this class has been moved to
L<Bric::Biz::ElementType::Parts::FieldType|Bric::Biz::ElementType::Parts::FieldType>.
Please use that class, instead.

=cut

use base 'Bric::Biz::ElementType::Parts::FieldType';

1;
__END__
