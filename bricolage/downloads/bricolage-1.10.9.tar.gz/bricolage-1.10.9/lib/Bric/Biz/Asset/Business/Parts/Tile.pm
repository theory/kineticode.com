package Bric::Biz::Asset::Business::Parts::Tile;
###############################################################################

=head1 NAME

Bric::Biz::Asset::Business::Parts::Tile - Deprecated; use Bric::Biz::Element instead

=head1 VERSION

$LastChangedRevision$

=cut

require Bric; our $VERSION = Bric->VERSION;

=head1 DATE

$LastChangedDate$

=head1 DESCRIPTION

The functionality of this class has been moved to
L<Bric::Biz::Element|Bric::Biz::Element>. Please use that class,
instead.

=cut

use base 'Bric::Biz::Element';

1;
__END__
